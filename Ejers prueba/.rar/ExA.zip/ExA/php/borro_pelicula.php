<?php

$id = $_POST["id"];


// El script devuelve alatoriamente 'error' o el 'id' de la nueva pelicula

echo  json_encode("ok");

?>